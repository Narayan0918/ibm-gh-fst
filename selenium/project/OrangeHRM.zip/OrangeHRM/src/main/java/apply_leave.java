import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class apply_leave {
	public static void main(String[] args) {
		
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		Actions builder = new Actions(driver);
		
		driver.get("https://hrm.alchemy.hguy.co/");
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Page title => "+driver.getTitle());
	
		builder.pause(Duration.ofSeconds(3)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='txtUsername']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='txtPassword']"));
		WebElement loginButton = driver.findElement(By.xpath("//input[@id='btnLogin']"));

		Action loginAction = builder.click(username).sendKeys("orange").click(password).sendKeys("5Nx#I6BK%r3$8vz0ch").pause(Duration.ofSeconds(2)).click(loginButton).build();
		loginAction.perform();
		
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Login Successful");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@id='mainMenuFirstLevelUnorderedList']/li[1]")));
		WebElement leavebutton = driver.findElement(By.xpath("//div[@id='dashboard-quick-launch-panel-menu_holder']/table/tbody/tr//td[4]//a"));
		
		builder.moveToElement(leavebutton).pause(1).click(leavebutton).build().perform();
		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//form[@id='frmLeaveApply']")));
		
		
		WebElement leaveType = driver.findElement(By.xpath("//select[@id='applyleave_txtLeaveType']")); 
		WebElement fromDate = driver.findElement(By.xpath("//input[@id='applyleave_txtFromDate']"));
		WebElement toDate = driver.findElement(By.xpath("//input[@id='applyleave_txtToDate']"));
		WebElement comment = driver.findElement(By.xpath("//textarea[@id='applyleave_txtComment']"));

		Select select = new Select(leaveType);
		
		
		select.selectByContainsVisibleText("Holiday");
		
		builder.pause(2)
		.click(fromDate).sendKeys("2026-09-02").pause(Duration.ofSeconds(2)).sendKeys(Keys.ENTER)
		.click(toDate).pause(Duration.ofSeconds(2)).sendKeys("2026-09-08").sendKeys(Keys.ENTER)
		.pause(Duration.ofSeconds(2)).sendKeys(comment,"Sick Leave")
		.pause(2).build().perform();
		
		WebElement applyLeave = driver.findElement(By.xpath("//input[@id='applyBtn']"));
		applyLeave.click();
		
		System.out.println("Leave Application successfull !");
		
		builder.pause(Duration.ofSeconds(2)).build().perform();
		
		WebElement myLeaveBtn = driver.findElement(By.xpath("//a[@id='menu_leave_viewMyLeaveList']"));
		myLeaveBtn.click();
		
		WebElement  leaveStatus = driver.findElement(By.xpath("//table[@id='resultTable']/tbody/tr[1]/td[6]"));
		
		System.out.println("Leave status => "+leaveStatus.getText());
	
		builder.pause(Duration.ofSeconds(10)).build().perform();

		driver.quit();
	}
}
