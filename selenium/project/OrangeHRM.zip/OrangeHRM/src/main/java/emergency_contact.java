import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class emergency_contact {
	public static void main(String[] args) {
		
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		Actions builder = new Actions(driver);
		
		driver.get("https://hrm.alchemy.hguy.co/");
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Page title => "+driver.getTitle());
	
		builder.pause(Duration.ofSeconds(3)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='txtUsername']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='txtPassword']"));
		WebElement loginButton = driver.findElement(By.xpath("//input[@id='btnLogin']"));

		Action loginAction = builder.click(username).sendKeys("orange").click(password).sendKeys("5Nx#I6BK%r3$8vz0ch").pause(Duration.ofSeconds(2)).click(loginButton).build();
		loginAction.perform();
		
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Login Successful");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@id='mainMenuFirstLevelUnorderedList']/li[1]")));
		WebElement MyInfobutton = driver.findElement(By.xpath("//a[@id='menu_pim_viewMyDetails']"));
		
		builder.moveToElement(MyInfobutton).pause(1).click(MyInfobutton).build().perform();
		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//input[@id='btnSave']")));
		
		WebElement emergencyContactButton = driver.findElement(By.xpath("//ul[@id='sidenav']/li/a[contains(text(),'Emergency Contacts')]"));
		emergencyContactButton.click();
		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//table[@id='emgcontact_list']")));

		List<WebElement> contactTableHeader = driver.findElements(By.xpath("//table[@id='emgcontact_list']/thead/tr/th"));
		List<WebElement> contactRows = driver.findElements(By.xpath("//table[@id='emgcontact_list']/tbody/tr"));
		
		if(contactRows.size() >0) {
			for (int i = 1; i <contactTableHeader.size() ; i++) {
			System.out.print(contactTableHeader.get(i).getText()+", ");
			}
			System.out.println("\n===================================================");
			for (int i = 0; i <contactRows.size() ; i++) {
				System.out.print(contactRows.get(i).getText()+" "+"\n---------------------------------------");
				System.out.println();
			}
		}
		
		
		System.out.println("Emergency contacts retrieved !");
		
		builder.pause(Duration.ofSeconds(10)).build().perform();

		driver.quit();
	}
}
