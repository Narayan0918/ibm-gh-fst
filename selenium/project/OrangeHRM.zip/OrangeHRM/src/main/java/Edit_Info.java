import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Edit_Info {
	public static void main(String[] args) {
		
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		Actions builder = new Actions(driver);
		
		driver.get("https://hrm.alchemy.hguy.co/");
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Page title => "+driver.getTitle());
	
		builder.pause(Duration.ofSeconds(3)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='txtUsername']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='txtPassword']"));
		WebElement loginButton = driver.findElement(By.xpath("//input[@id='btnLogin']"));

		Action loginAction = builder.click(username).sendKeys("orange").click(password).sendKeys("5Nx#I6BK%r3$8vz0ch").pause(Duration.ofSeconds(2)).click(loginButton).build();
		loginAction.perform();
		
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Login Successful");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@id='mainMenuFirstLevelUnorderedList']/li[1]")));
		WebElement MyInfobutton = driver.findElement(By.xpath("//a[@id='menu_pim_viewMyDetails']"));
		
		builder.moveToElement(MyInfobutton).pause(1).click(MyInfobutton).build().perform();
		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//input[@id='btnSave']")));
		
		WebElement editButton = driver.findElement(By.xpath("//input[@id='btnSave']"));
		editButton.click();
		
		
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[@id='frmEmpPersonalDetails']")));
		
		WebElement firstname = driver.findElement(By.xpath("//input[@id='personal_txtEmpFirstName']")); 
		WebElement lastname = driver.findElement(By.xpath("//input[@id='personal_txtEmpLastName']"));
		WebElement checkbox = driver.findElement(By.xpath("//input[@id='personal_optGender_1']"));
		WebElement saveEmpBtn = driver.findElement(By.xpath("//input[@id='btnSave']"));
		WebElement dob = driver.findElement(By.xpath("//input[@id='personal_DOB']"));

		firstname.clear();
		lastname.clear();
		dob.clear();
		
		builder.pause(2)
		.click(firstname).sendKeys("John").pause(1)
		.click(lastname).sendKeys("Doe").pause(2)
		.click(checkbox).click(dob).sendKeys("1998-12-12")
		.pause(2).build().perform();
		
//		WebElement loginUsername = driver.findElement(By.xpath("//input[@id='user_name']"));
//		WebElement loginPassword = driver.findElement(By.xpath("//input[@id='user_password']"));
//		WebElement loginCnfPassword = driver.findElement(By.xpath("//input[@id='re_password']"));
		WebElement nationality = driver.findElement(By.xpath("//select[@id='personal_cmbNation']"));
		Select select = new Select(nationality);
//		
//		
//		builder.pause(2)
//		.click(loginUsername).sendKeys("narayan").pause(1)
//		.click(loginPassword).sendKeys("Heybuddy@123").pause(1)
//		.click(loginCnfPassword).sendKeys("Heybuddy@123").pause(1)
//		.build().perform();
//		
		select.selectByVisibleText("Indian");
		saveEmpBtn.click();
		
		System.out.println("Employee Saved successfully!");
		
		builder.pause(Duration.ofSeconds(10)).build().perform();

		driver.quit();
	}
}
