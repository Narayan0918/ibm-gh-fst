import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Orange_header_url {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		Actions builder = new Actions(driver);
		
		
		driver.get("https://hrm.alchemy.hguy.co/");
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Page title => "+driver.getTitle());
		builder.pause(Duration.ofSeconds(5)).build().perform();
		WebElement imageElement = driver.findElement(By.xpath("//div[@id='divLogo']/img"));
		System.out.println("Logo URL => "+imageElement.getAttribute("src"));
		
		driver.quit();
	}
}
