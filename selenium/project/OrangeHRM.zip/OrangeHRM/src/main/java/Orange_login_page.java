import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Orange_login_page {
	public static void main(String[] args) {
		
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		Actions builder = new Actions(driver);
		
		driver.get("https://hrm.alchemy.hguy.co/");
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Page title => "+driver.getTitle());
	
		builder.pause(Duration.ofSeconds(5)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='txtUsername']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='txtPassword']"));
		WebElement loginButton = driver.findElement(By.xpath("//input[@id='btnLogin']"));

		Action loginAction = builder.click(username).sendKeys("orange").click(password).sendKeys("5Nx#I6BK%r3$8vz0ch").pause(Duration.ofSeconds(2)).click(loginButton).build();
		loginAction.perform();
		
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Login Successful");
		builder.pause(Duration.ofSeconds(10)).build().perform();

		driver.quit();
	}
}
