import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class qualification_edit {
	public static void main(String[] args) {
		
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		Actions builder = new Actions(driver);
		
		driver.get("https://hrm.alchemy.hguy.co/");
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Page title => "+driver.getTitle());
	
		builder.pause(Duration.ofSeconds(3)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='txtUsername']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='txtPassword']"));
		WebElement loginButton = driver.findElement(By.xpath("//input[@id='btnLogin']"));

		Action loginAction = builder.click(username).sendKeys("orange").click(password).sendKeys("5Nx#I6BK%r3$8vz0ch").pause(Duration.ofSeconds(2)).click(loginButton).build();
		loginAction.perform();
		
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Login Successful");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@id='mainMenuFirstLevelUnorderedList']/li[1]")));
		WebElement MyInfobutton = driver.findElement(By.xpath("//a[@id='menu_pim_viewMyDetails']"));
		
		builder.moveToElement(MyInfobutton).pause(1).click(MyInfobutton).build().perform();
		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//input[@id='btnSave']")));
		
		WebElement QualificationButton = driver.findElement(By.xpath("//ul[@id='sidenav']/li/a[contains(text(),'Qualifications')]"));
		QualificationButton.click();
		
		WebElement workExp = driver.findElement(By.xpath("//input[@id='addWorkExperience']"));
		
		workExp.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='changeWorkExperience']")));
		
		WebElement company = driver.findElement(By.xpath("//input[@id='experience_employer']")); 
		WebElement jobTitle = driver.findElement(By.xpath("//input[@id='experience_jobtitle']"));
		WebElement fromDate = driver.findElement(By.xpath("//input[@id='experience_from_date']"));
//		WebElement toDate = driver.findElement(By.xpath("//input[@id='experience_to_date']"));
		WebElement comment = driver.findElement(By.xpath("//textarea[@id='experience_comments']"));

		builder.pause(2)
		.click(company).sendKeys("IBM").pause(1)
		.click(jobTitle).sendKeys("ASE").pause(Duration.ofSeconds(2))
		.click(fromDate).sendKeys("2026-05-18").pause(Duration.ofSeconds(2))
		.sendKeys(Keys.ENTER).pause(Duration.ofSeconds(2)).sendKeys(comment,"My first job")
		.pause(2).build().perform();
		
		WebElement saveWorkData = driver.findElement(By.xpath("//input[@id='btnWorkExpSave']"));
		saveWorkData.click();
		
		System.out.println("Employee Saved successfully!");
		
		builder.pause(Duration.ofSeconds(10)).build().perform();

		driver.quit();
	}
}
