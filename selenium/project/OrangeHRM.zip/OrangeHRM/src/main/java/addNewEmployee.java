
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class addNewEmployee {
	public static void main(String[] args) {
		
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		Actions builder = new Actions(driver);
		
		driver.get("https://hrm.alchemy.hguy.co/");
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Page title => "+driver.getTitle());
	
		builder.pause(Duration.ofSeconds(3)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='txtUsername']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='txtPassword']"));
		WebElement loginButton = driver.findElement(By.xpath("//input[@id='btnLogin']"));

		Action loginAction = builder.click(username).sendKeys("orange").click(password).sendKeys("5Nx#I6BK%r3$8vz0ch").pause(Duration.ofSeconds(2)).click(loginButton).build();
		loginAction.perform();
		
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		System.out.println("Login Successful");
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@id='mainMenuFirstLevelUnorderedList']/li[1]")));
		WebElement PIMbutton = driver.findElement(By.xpath("//a[@id='menu_pim_viewPimModule']"));
		
		builder.moveToElement(PIMbutton).pause(1).click(PIMbutton).build().perform();
		
		builder.pause(5).build().perform();
		
		WebElement addEmpButton = driver.findElement(By.xpath("//a[@id='menu_pim_addEmployee']"));
		addEmpButton.click();
		
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='addEmployeeTbl']")));
		
		WebElement firstname = driver.findElement(By.xpath("//input[@id='firstName']")); 
		WebElement middlename = driver.findElement(By.xpath("//input[@id='middleName']"));
		WebElement lastname = driver.findElement(By.xpath("//input[@id='lastName']"));
//		WebElement checkbox = driver.findElement(By.xpath("//input[@id='chkLogin']"));
		WebElement saveEmpBtn = driver.findElement(By.xpath("//input[@id='btnSave']"));

		builder.pause(2)
		.click(firstname).sendKeys("Narayan").pause(1)
		.click(middlename).sendKeys("Raj").pause(1)
		.click(lastname).sendKeys("Dubey").pause(2)
		.pause(2).build().perform();
		
		saveEmpBtn.click();
		
		WebElement searchEmp = driver.findElement(By.xpath("//a[@id='menu_pim_viewEmployeeList']"));
		
		
		builder.pause(2)
		.moveToElement(searchEmp).pause(1).click(searchEmp).build().perform();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//form[@id='search_form']")));
		
		WebElement empSearchUsername = driver.findElement(By.xpath("//input[@id='empsearch_employee_name_empName']"));
//		WebElement empIdSearch = driver.findElement(By.xpath("//input[@id='empsearch_id']"));
		WebElement searchBtn = driver.findElement(By.xpath("//input[@id='searchBtn']"));
		
		builder.pause(2)
		.click(empSearchUsername).sendKeys("narayan").pause(1)
		.click(searchBtn)
		.build().perform();

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='tableWrapper']//tbody/tr/td[2]")));
		String searchTableData = driver.findElement(By.xpath("//div[@id='tableWrapper']//tbody/tr/td[3]/a")).getText();
		
//		builder.pause(Duration.ofSeconds(2)).build().perform();
		
		if(searchTableData=="Narayan Raj")	{
			System.out.println("Employee found");
		}else {
			System.out.println(searchTableData);
		}
		
		System.out.println("Employee Saved successfully!");
		
		builder.pause(Duration.ofSeconds(10)).build().perform();

		driver.quit();
	}
}
