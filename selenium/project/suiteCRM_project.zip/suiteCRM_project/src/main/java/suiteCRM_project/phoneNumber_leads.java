package suiteCRM_project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class phoneNumber_leads {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		Actions builder = new Actions(driver);
		
		
		driver.get("https://crm.alchemy.hguy.co");
		wait.until(ExpectedConditions.titleIs("SuiteCRM"));
		System.out.println("Page title => "+driver.getTitle());
	
		builder.pause(Duration.ofSeconds(10)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='username']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='password']"));
		WebElement loginButton = driver.findElement(By.xpath("//button[@id='login-button']"));

		
		
		Action loginAction = builder.click(username).sendKeys("admin").pause(Duration.ofSeconds(2)).click(password).sendKeys("5Nx#I6BK%r3$8vz0ch").pause(Duration.ofSeconds(2)).click(loginButton).build();
		loginAction.perform();
		
		builder.pause(Duration.ofSeconds(10)).build().perform();

		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='navbar-collapse collapse collapsenav ng-tns-c2316037842-2']//child::ul")));
		
		WebElement leadsMenu = driver.findElement(By.xpath("//div[@class='navbar-collapse collapse collapsenav ng-tns-c2316037842-2']//child::ul[@class='navbar-nav ng-tns-c2316037842-2 ng-star-inserted']/child::li[4]//child::a[@class='top-nav-link nav-link-nongrouped dropdown-toggle hover-enabled ng-star-inserted']"));
		
		leadsMenu.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//scrm-table//scrm-table-body//tbody/tr")));
		driver.findElement(By.xpath("//scrm-table//scrm-table-body//tbody/tr/td[3]/scrm-field/scrm-dynamic-field/a")).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[@class='detail field-layout']//scrm-dynamic-field")));
		System.out.println("Phone number => "+driver.findElement(By.xpath("//form[@class='detail field-layout']//scrm-dynamic-field//scrm-phone-detail")).getText());
		
		
		builder.pause(Duration.ofSeconds(10)).build().perform();

		
		
		
		
		driver.quit();
	}
}
