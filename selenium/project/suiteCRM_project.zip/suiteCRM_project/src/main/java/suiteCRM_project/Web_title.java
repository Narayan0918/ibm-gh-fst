package suiteCRM_project;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Web_title {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		driver.get("https://crm.alchemy.hguy.co");
		wait.until(ExpectedConditions.titleIs("SuiteCRM"));
		System.out.println("Page title => "+driver.getTitle());
		
		driver.quit();
	}
}
