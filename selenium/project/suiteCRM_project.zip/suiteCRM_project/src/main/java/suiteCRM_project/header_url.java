package suiteCRM_project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class header_url {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		Actions builder = new Actions(driver);
		
		
		driver.get("https://crm.alchemy.hguy.co");
		wait.until(ExpectedConditions.titleIs("SuiteCRM"));
		System.out.println("Page title => "+driver.getTitle());
		builder.pause(Duration.ofSeconds(10)).build().perform();
		WebElement imageElement = driver.findElement(By.xpath("//scrm-image[@image='company_logo']//following::img[@class='ng-star-inserted image-company_logo']"));
		System.out.println("Logo URL => "+imageElement.getDomAttribute("src"));
		
		
		driver.quit();
	}
}
