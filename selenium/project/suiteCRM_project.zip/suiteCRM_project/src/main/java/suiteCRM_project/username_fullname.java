package suiteCRM_project;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class username_fullname {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		Actions builder = new Actions(driver);
		
		
		driver.get("https://demo.suiteondemand.com/index.php?action=Login&module=Users");
		wait.until(ExpectedConditions.titleIs("SuiteCRM Demo"));
		System.out.println("Page title => "+driver.getTitle());
	
		builder.pause(Duration.ofSeconds(5)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='user_name']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='username_password']"));
		WebElement loginButton = driver.findElement(By.xpath("//input[@id='bigbutton']"));

		
		
		Action loginAction = builder.click(username).sendKeys("will").pause(Duration.ofSeconds(1)).click(password).sendKeys("will").pause(Duration.ofSeconds(1)).click(loginButton).build();
		loginAction.perform();
		
		builder.pause(Duration.ofSeconds(5)).build().perform();

		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("nav")));
		
		WebElement salesMenu = driver.findElement(By.xpath("//nav[@class='navbar navbar-inverse navbar-fixed-top']//div[@id='toolbar']/ul/li[2]"));
		WebElement leadsMenu = driver.findElement(By.xpath("//li/a[@id='moduleTab_6_Leads']"));
		

		
		builder.moveToElement(salesMenu).click(leadsMenu).build().perform();
		
		leadsMenu.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table/thead/following::tbody/tr[contains(@class,'ListRowS1')]")));
		
		List<WebElement> rows= driver.findElements(By.xpath("//table/thead/following::tbody/tr[contains(@class,'ListRowS1')]"));
        List<WebElement> fullname= driver.findElements(By.xpath("//table/thead/following::tbody/tr/td[3]"));
        List<WebElement> username_table= driver.findElements(By.xpath("//table/thead/following::tbody/tr/td[8]"));

		
		builder.pause(Duration.ofSeconds(3)).build().perform();

		for (int i = 0; i < fullname.size()-1; i++) {
			System.out.println(i+1 +". " +fullname.get(i).getText()+" => "+username_table.get(i).getText());
		}
		
		
		builder.pause(Duration.ofSeconds(3)).build().perform();

		
		
		driver.quit();
	}
}
