package suiteCRM_project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class copyright_text {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		Actions builder = new Actions(driver);
		
		
		driver.get("https://crm.alchemy.hguy.co");
		wait.until(ExpectedConditions.titleIs("SuiteCRM"));
		System.out.println("Page title => "+driver.getTitle());
	
		builder.pause(Duration.ofSeconds(10)).build().perform();
		
		WebElement copyrightElement1 = driver.findElement(By.xpath("//div[@class='copyright-links']//child::a[1]"));
		WebElement copyrightElement2 = driver.findElement(By.xpath("//div[@class='copyright-links']//child::a[2]"));

		System.out.println("Copyright text => \n"+copyrightElement1.getText()+"\n"+copyrightElement2.getText());
		
		
		driver.quit();
	}
}
