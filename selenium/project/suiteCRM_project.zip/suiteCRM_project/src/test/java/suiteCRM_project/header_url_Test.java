package suiteCRM_project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class header_url_Test {
	
		WebDriver driver;
		WebDriverWait wait;
		Actions builder;
		@BeforeClass
		public void setup() {
			driver = new FirefoxDriver();
			wait = new WebDriverWait(driver, Duration.ofSeconds(15));
			builder = new Actions(driver);
			driver.get("https://crm.alchemy.hguy.co");
			
		}
		
		
		@Test
		public void get_Title() {
			wait.until(ExpectedConditions.titleIs("SuiteCRM"));
			Assert.assertEquals(driver.getTitle(), "SuiteCRM");
			System.out.println("Page title => "+driver.getTitle());		
		}
		
		@Test
		public void header_url() {
			builder.pause(Duration.ofSeconds(10)).build().perform();
			WebElement imageElement = driver.findElement(By.xpath("//scrm-image[@image='company_logo']//following::img[@class='ng-star-inserted image-company_logo']"));
			System.out.println("Logo URL => "+imageElement.getDomAttribute("src"));
		}
		
		
		@AfterClass
		public void tearDown() {
			driver.quit();
		}

}
