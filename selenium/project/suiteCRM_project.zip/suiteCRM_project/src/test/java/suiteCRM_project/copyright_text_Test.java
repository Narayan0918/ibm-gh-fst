package suiteCRM_project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class copyright_text_Test {
	
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	@BeforeClass
	public void setup() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		builder = new Actions(driver);
		driver.get("https://crm.alchemy.hguy.co");
	}
		
	@Test
	public void get_Title() {
		wait.until(ExpectedConditions.titleIs("SuiteCRM"));
		Assert.assertEquals(driver.getTitle(), "SuiteCRM");
		System.out.println("Page title => "+driver.getTitle());		
	}
	
	
	@Test
	public void test_copyright() {
		builder.pause(Duration.ofSeconds(5)).build().perform();
		WebElement copyrightElement1 = driver.findElement(By.xpath("//div[@class='copyright-links']//child::a[1]"));
		WebElement copyrightElement2 = driver.findElement(By.xpath("//div[@class='copyright-links']//child::a[2]"));
		Assert.assertEquals(copyrightElement1.getText()+" "+copyrightElement2.getText(), "© Supercharged by SuiteCRM © Powered By SugarCRM");
		System.out.println("Copyright text => \n"+copyrightElement1.getText()+"\n"+copyrightElement2.getText());
		
	}
		
		
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	
}
