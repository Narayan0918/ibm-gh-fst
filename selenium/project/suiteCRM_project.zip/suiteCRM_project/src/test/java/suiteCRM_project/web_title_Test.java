package suiteCRM_project;


import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class web_title_Test {
	WebDriver driver;
	WebDriverWait wait;
	
	@BeforeClass
	public void setup() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		driver.get("https://crm.alchemy.hguy.co");
	}
		
	@Test
	public void get_Title() {
		wait.until(ExpectedConditions.titleIs("SuiteCRM"));
		Assert.assertEquals(driver.getTitle(), "SuiteCRM");
		System.out.println("Page title => "+driver.getTitle());		
	}
		
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
		
}
