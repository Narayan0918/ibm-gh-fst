package suiteCRM_project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class opportunities_menu_Test {

	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	@BeforeClass
	public void setup() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		builder = new Actions(driver);
		driver.get("https://crm.alchemy.hguy.co");
	}
		
	@Test(priority = 1)
	public void get_Title() {
		wait.until(ExpectedConditions.titleIs("SuiteCRM"));
		Assert.assertEquals(driver.getTitle(), "SuiteCRM");
		System.out.println("Page title => "+driver.getTitle());		
	}
	
	@Test(priority = 2)
	public void login() {
		builder.pause(Duration.ofSeconds(10)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='username']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='password']"));
		WebElement loginButton = driver.findElement(By.xpath("//button[@id='login-button']"));

		Action loginAction = builder.click(username).sendKeys("admin").click(password).sendKeys("5Nx#I6BK%r3$8vz0ch").pause(Duration.ofSeconds(2)).click(loginButton).build();
		loginAction.perform();
		Assert.assertEquals(driver.getTitle(), "SuiteCRM");
		
	}
	
	@Test(priority = 3)
	public void opportunityButton_check() {
		
		builder.pause(Duration.ofSeconds(5)).build().perform();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='navbar-collapse collapse collapsenav ng-tns-c2316037842-2']//child::ul[@class='navbar-nav ng-tns-c2316037842-2 ng-star-inserted']/child::li[3]//child::span//child::span")));
		WebElement opportunityButton = driver.findElement(By.xpath("//div[@class='navbar-collapse collapse collapsenav ng-tns-c2316037842-2']//child::ul[@class='navbar-nav ng-tns-c2316037842-2 ng-star-inserted']/child::li[3]//child::span//child::span"));
		Assert.assertEquals(opportunityButton.getText(), "Opportunities");
		System.out.println("Button found => "+opportunityButton.getText());
		
	}
		
	@AfterClass
	public void tearDown() {
		builder.pause(Duration.ofSeconds(5)).build().perform();
		driver.quit();

	}

}
