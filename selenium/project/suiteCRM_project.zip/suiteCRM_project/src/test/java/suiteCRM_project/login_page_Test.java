package suiteCRM_project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class login_page_Test {
		
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	@BeforeClass
	public void setup() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		builder = new Actions(driver);
		driver.get("https://crm.alchemy.hguy.co");
	}
		
	@Test
	public void get_Title() {
		wait.until(ExpectedConditions.titleIs("SuiteCRM"));
		Assert.assertEquals(driver.getTitle(), "SuiteCRM");
		System.out.println("Page title => "+driver.getTitle());		
	}
	
	@Test
	public void login() {
		builder.pause(Duration.ofSeconds(10)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='username']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='password']"));
		WebElement loginButton = driver.findElement(By.xpath("//button[@id='login-button']"));

		Action loginAction = builder.click(username).sendKeys("admin").click(password).sendKeys("5Nx#I6BK%r3$8vz0ch").pause(Duration.ofSeconds(2)).click(loginButton).build();
		loginAction.perform();
		Assert.assertEquals(driver.getTitle(), "SuiteCRM");
		builder.pause(Duration.ofSeconds(5)).build().perform();
	}
		

	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
