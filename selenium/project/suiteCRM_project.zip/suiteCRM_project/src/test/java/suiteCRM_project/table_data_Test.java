package suiteCRM_project;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class table_data_Test {
	
	WebDriver driver;
	WebDriverWait wait;
	Actions builder;
	@BeforeClass
	public void setup() {
		driver = new FirefoxDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		builder = new Actions(driver);
		
		driver.get("https://demo.suiteondemand.com/index.php?action=Login&module=Users");
	}
		
	@Test(priority = 1)
	public void get_Title() {
		wait.until(ExpectedConditions.titleIs("SuiteCRM Demo"));
		Assert.assertEquals(driver.getTitle(), "SuiteCRM Demo");
		System.out.println("Page title => "+driver.getTitle());		
	}
	
	@Test(priority = 2)
	public void login() {
		builder.pause(Duration.ofSeconds(5)).build().perform();
		
		WebElement username = driver.findElement(By.xpath("//input[@name='user_name']"));
		WebElement password = driver.findElement(By.xpath("//input[@name='username_password']"));
		WebElement loginButton = driver.findElement(By.xpath("//input[@id='bigbutton']"));

		
		
		Action loginAction = builder.click(username).sendKeys("will").pause(Duration.ofSeconds(1)).click(password).sendKeys("will").pause(Duration.ofSeconds(1)).click(loginButton).build();
		loginAction.perform();
		Assert.assertEquals(driver.getTitle(), "SuiteCRM Demo");
		
	}
	
	@Test(priority = 3)
	public void load_table() {
		builder.pause(Duration.ofSeconds(5)).build().perform();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("nav")));
		
		WebElement salesMenu = driver.findElement(By.xpath("//nav[@class='navbar navbar-inverse navbar-fixed-top']//div[@id='toolbar']/ul/li[2]"));
		WebElement accountMenu = driver.findElement(By.xpath("//li/a[@id='moduleTab_6_Accounts']"));
		
		builder.moveToElement(salesMenu).click(accountMenu).build().perform();
		accountMenu.click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table/thead/following::tbody/tr[contains(@class,'ListRowS1')]")));
		
		List<WebElement> rows= driver.findElements(By.xpath("//table/thead/following::tbody/tr[contains(@class,'oddListRowS1')]"));
        List<WebElement> cols= driver.findElements(By.xpath("//table/tbody/tr/td"));
		
		builder.pause(Duration.ofSeconds(3)).build().perform();
		Assert.assertEquals(rows.size(), 10);
		
		int count = 0;
		for (int i =0;i<rows.size();i+=2) {
			System.out.println(rows.get(i).getText());
			System.out.println();
			count++;
			if(count==5) {
				break;
			}
		}
		
	}
	
	@AfterClass
	public void tearDown() {
		builder.pause(Duration.ofSeconds(5)).build().perform();
		driver.quit();

	}
}
