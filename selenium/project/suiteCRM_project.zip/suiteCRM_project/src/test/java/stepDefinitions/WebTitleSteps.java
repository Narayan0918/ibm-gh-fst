package stepDefinitions;

/**
 * No unique steps for web_title.feature — all steps are in CommonSteps.
 * This class exists only so the glue package includes the feature's tag.
 */
public class WebTitleSteps {
}
