package stepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

/**
 * Unique step definitions for table_data.feature.
 * Accesses driver/wait/builder via BaseClass static fields — no inheritance needed.
 */
public class TableDataSteps {

    @And("I hover over the Sales menu and click on Accounts")
    public void i_hover_over_the_sales_menu_and_click_on_accounts() {
        WebElement salesMenu = BaseClass.driver.findElement(
                By.xpath("//nav[@class='navbar navbar-inverse navbar-fixed-top']//div[@id='toolbar']/ul/li[2]"));
        WebElement accountMenu = BaseClass.driver.findElement(
                By.xpath("//li/a[@id='moduleTab_6_Accounts']"));

        BaseClass.builder.moveToElement(salesMenu).click(accountMenu).build().perform();
        accountMenu.click();
    }

    @And("I wait for the accounts table to load")
    public void i_wait_for_the_accounts_table_to_load() {
        BaseClass.wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//table/thead/following::tbody/tr[contains(@class,'ListRowS1')]")));
    }

    @Then("the accounts table should contain {int} rows")
    public void the_accounts_table_should_contain_rows(int expectedRowCount) {
        List<WebElement> rows = BaseClass.driver.findElements(
                By.xpath("//table/thead/following::tbody/tr[contains(@class,'oddListRowS1')]"));
        Assert.assertEquals(rows.size(), expectedRowCount);
    }

    @And("the first 5 account row texts should be printed")
    public void the_first_5_account_row_texts_should_be_printed() {
        List<WebElement> rows = BaseClass.driver.findElements(
                By.xpath("//table/thead/following::tbody/tr[contains(@class,'oddListRowS1')]"));
        int count = 0;
        for (int i = 0; i < rows.size(); i += 2) {
            System.out.println(rows.get(i).getText());
            System.out.println();
            count++;
            if (count == 5) {
                break;
            }
        }
    }
}
