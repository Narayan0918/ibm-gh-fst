package stepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

/**
 * Unique step definitions for username_fullname.feature.
 * Accesses driver/wait/builder via BaseClass static fields — no inheritance needed.
 */
public class UsernameFullnameSteps {

    @And("I hover over the Sales menu and click on Leads")
    public void i_hover_over_the_sales_menu_and_click_on_leads() {
        WebElement salesMenu = BaseClass.driver.findElement(
                By.xpath("//nav[@class='navbar navbar-inverse navbar-fixed-top']//div[@id='toolbar']/ul/li[2]"));
        WebElement leadsMenu = BaseClass.driver.findElement(
                By.xpath("//li/a[@id='moduleTab_6_Leads']"));

        BaseClass.builder.moveToElement(salesMenu).click(leadsMenu).build().perform();
        leadsMenu.click();
    }

    @And("I wait for the leads list table to load")
    public void i_wait_for_the_leads_list_table_to_load() {
        BaseClass.wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//table/thead/following::tbody/tr[contains(@class,'ListRowS1')]")));
    }

    @Then("the leads table should contain {int} rows")
    public void the_leads_table_should_contain_rows(int expectedRowCount) {
        List<WebElement> rows = BaseClass.driver.findElements(
                By.xpath("//table/thead/following::tbody/tr[contains(@class,'ListRowS1')]"));
        Assert.assertEquals(rows.size(), expectedRowCount);
    }

    @And("the first 10 lead fullname and username pairs should be printed")
    public void the_first_10_lead_fullname_and_username_pairs_should_be_printed() {
        List<WebElement> fullname = BaseClass.driver.findElements(
                By.xpath("//table/thead/following::tbody/tr/td[3]"));
        List<WebElement> usernameTable = BaseClass.driver.findElements(
                By.xpath("//table/thead/following::tbody/tr/td[8]"));

        for (int i = 0; i < fullname.size() - 1; i++) {
            if (i == 10) {
                break;
            }
            System.out.println((i + 1) + ". " + fullname.get(i).getText()
                    + " => " + usernameTable.get(i).getText());
        }
    }
}
