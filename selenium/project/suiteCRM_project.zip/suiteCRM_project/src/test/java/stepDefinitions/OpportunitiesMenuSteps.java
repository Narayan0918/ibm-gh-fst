package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

/**
 * Unique step definitions for opportunities_menu.feature.
 * Accesses driver/wait via BaseClass static fields — no inheritance needed.
 */
public class OpportunitiesMenuSteps {

    @Then("the Opportunities navigation button should be visible")
    public void the_opportunities_navigation_button_should_be_visible() {
        BaseClass.wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@class='navbar-collapse collapse collapsenav ng-tns-c2316037842-2']"
                        + "//child::ul[@class='navbar-nav ng-tns-c2316037842-2 ng-star-inserted']"
                        + "/child::li[3]//child::span//child::span")));
    }

    @And("the Opportunities button text should be {string}")
    public void the_opportunities_button_text_should_be(String expectedText) {
        WebElement opportunityButton = BaseClass.driver.findElement(
                By.xpath("//div[@class='navbar-collapse collapse collapsenav ng-tns-c2316037842-2']"
                        + "//child::ul[@class='navbar-nav ng-tns-c2316037842-2 ng-star-inserted']"
                        + "/child::li[3]//child::span//child::span"));
        Assert.assertEquals(opportunityButton.getText(), expectedText);
        System.out.println("Button found => " + opportunityButton.getText());
    }
}
