package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import io.cucumber.java.en.Then;

/**
 * Unique step definitions for copyright_text.feature.
 * Accesses driver via BaseClass static fields — no inheritance needed.
 */
public class CopyrightTextSteps {

    @Then("the copyright footer text should be {string}")
    public void the_copyright_footer_text_should_be(String expectedText) {
        WebElement copyrightElement1 = BaseClass.driver.findElement(
                By.xpath("//div[@class='copyright-links']//child::a[1]"));
        WebElement copyrightElement2 = BaseClass.driver.findElement(
                By.xpath("//div[@class='copyright-links']//child::a[2]"));

        String actualText = copyrightElement1.getText() + " " + copyrightElement2.getText();
        Assert.assertEquals(actualText, expectedText);
        System.out.println("Copyright text => \n" + copyrightElement1.getText()
                + "\n" + copyrightElement2.getText());
    }
}
