package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import io.cucumber.java.en.Then;

/**
 * Unique step definitions for header_url.feature.
 * Accesses driver via BaseClass static fields — no inheritance needed.
 */
public class HeaderUrlSteps {

    @Then("the header company logo image source URL should be printed")
    public void the_header_company_logo_image_source_url_should_be_printed() {
        WebElement imageElement = BaseClass.driver.findElement(
                By.xpath("//scrm-image[@image='company_logo']//following::img[@class='ng-star-inserted image-company_logo']"));
        String logoUrl = imageElement.getDomAttribute("src");
        Assert.assertNotNull(logoUrl, "Logo image source URL should not be null");
        System.out.println("Logo URL => " + logoUrl);
    }
}
