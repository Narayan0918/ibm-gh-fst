package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * BaseClass is a plain data-holder for shared WebDriver state.
 *
 * It contains NO step definitions and NO hooks — just public static fields.
 * This means it is safe for any class to reference these fields directly
 * without extending it, and it never triggers Cucumber's restriction:
 * "You're not allowed to extend classes that define Step Definitions or hooks."
 *
 * Lifecycle:
 *   CommonSteps owns the single @Before / @After that initialises and
 *   cleans up these fields once per scenario.
 */
public class BaseClass {

    public static WebDriver      driver;
    public static WebDriverWait  wait;
    public static Actions        builder;
}
