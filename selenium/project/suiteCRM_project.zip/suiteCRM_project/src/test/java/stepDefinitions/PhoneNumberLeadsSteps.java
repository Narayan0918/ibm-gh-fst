package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

/**
 * Unique step definitions for phoneNumber_leads.feature.
 * Accesses driver/wait via BaseClass static fields — no inheritance needed.
 */
public class PhoneNumberLeadsSteps {

    @And("I navigate to the Leads menu")
    public void i_navigate_to_the_leads_menu() {
        BaseClass.wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@class='navbar-collapse collapse collapsenav ng-tns-c2316037842-2']//child::ul")));

        WebElement leadsMenu = BaseClass.driver.findElement(By.xpath(
                "//div[@class='navbar-collapse collapse collapsenav ng-tns-c2316037842-2']"
                + "//child::ul[@class='navbar-nav ng-tns-c2316037842-2 ng-star-inserted']"
                + "/child::li[4]//child::a[@class='top-nav-link nav-link-nongrouped dropdown-toggle hover-enabled ng-star-inserted']"));
        leadsMenu.click();
    }

    @And("I wait for the leads table to load")
    public void i_wait_for_the_leads_table_to_load() {
        BaseClass.wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//scrm-table//scrm-table-body//tbody/tr")));
    }

    @And("I click on the first lead in the table")
    public void i_click_on_the_first_lead_in_the_table() {
        BaseClass.driver.findElement(
                By.xpath("//scrm-table//scrm-table-body//tbody/tr/td[3]/scrm-field/scrm-dynamic-field/a"))
              .click();
    }

    @And("I wait for the lead detail page to load")
    public void i_wait_for_the_lead_detail_page_to_load() {
        BaseClass.wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//form[@class='detail field-layout']//scrm-dynamic-field")));
    }

    @Then("the lead phone number should be {string}")
    public void the_lead_phone_number_should_be(String expectedPhone) {
        WebElement phoneElement = BaseClass.driver.findElement(
                By.xpath("//form[@class='detail field-layout']//scrm-dynamic-field//scrm-phone-detail"));
        Assert.assertEquals(phoneElement.getText(), expectedPhone);
        System.out.println("Phone number => " + phoneElement.getText());
    }
}
