package stepDefinitions;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * CommonSteps is the ONLY class that owns @Before and @After.
 * This ensures exactly ONE browser is opened and closed per scenario,
 * regardless of how many step-definition classes are in the glue package.
 *
 * This class does NOT extend BaseClass (Cucumber forbids extending a class
 * that has hooks/step-defs). Instead it writes directly to the public static
 * fields on BaseClass so that every other step class can read them.
 *
 * Shared steps defined here:
 *   SuiteCRM (crm.alchemy.hguy.co):
 *     - I open the SuiteCRM login page at {string}
 *     - the page finishes loading
 *     - the browser title should be {string}
 *     - I wait for the page to fully render
 *     - I enter username {string} and password {string}
 *     - I click the login button
 *     - I wait for the dashboard to load
 *   SuiteCRM Demo (demo.suiteondemand.com):
 *     - I open the SuiteCRM Demo login page at {string}
 *     - I enter demo username {string} and password {string}
 *     - I click the demo login button
 *     - I wait for the demo dashboard to load
 */
public class CommonSteps {

    // ─── Lifecycle ───────────────────────────────────────────────────────────────

    @Before
    public void setUp() {
        BaseClass.driver  = new FirefoxDriver();
        BaseClass.wait    = new WebDriverWait(BaseClass.driver, Duration.ofSeconds(25));
        BaseClass.builder = new Actions(BaseClass.driver);
    }

    @After
    public void tearDown() {
        if (BaseClass.driver != null) {
            BaseClass.driver.quit();
            BaseClass.driver = null;
        }
    }

    // ─── SuiteCRM (crm.alchemy.hguy.co) shared steps ────────────────────────────

    @Given("I open the SuiteCRM login page at {string}")
    public void i_open_the_suiteCRM_login_page_at(String url) {
        BaseClass.driver.get(url);
    }

    @When("the page finishes loading")
    public void the_page_finishes_loading() {
        BaseClass.wait.until(ExpectedConditions.titleContains("SuiteCRM"));
    }

    @Then("the browser title should be {string}")
    public void the_browser_title_should_be(String expectedTitle) {
        Assert.assertEquals(BaseClass.driver.getTitle(), expectedTitle);
        System.out.println("Page title => " + BaseClass.driver.getTitle());
    }

    @And("I wait for the page to fully render")
    public void i_wait_for_the_page_to_fully_render() {
        BaseClass.builder.pause(Duration.ofSeconds(10)).build().perform();
    }

    @And("I enter username {string} and password {string}")
    public void i_enter_username_and_password(String username, String password) {
        BaseClass.builder.pause(Duration.ofSeconds(10)).build().perform();

        WebElement usernameField = BaseClass.driver.findElement(By.xpath("//input[@name='username']"));
        WebElement passwordField = BaseClass.driver.findElement(By.xpath("//input[@name='password']"));

        BaseClass.builder.click(usernameField).sendKeys(username)
                         .click(passwordField).sendKeys(password)
                         .build().perform();
    }

    @And("I click the login button")
    public void i_click_the_login_button() {
        WebElement loginButton = BaseClass.driver.findElement(By.xpath("//button[@id='login-button']"));
        Action clickLogin = BaseClass.builder.pause(Duration.ofSeconds(2)).click(loginButton).build();
        clickLogin.perform();
    }

    @And("I wait for the dashboard to load")
    public void i_wait_for_the_dashboard_to_load() {
        BaseClass.builder.pause(Duration.ofSeconds(5)).build().perform();
    }

    // ─── SuiteCRM Demo (demo.suiteondemand.com) shared steps ─────────────────────

    @Given("I open the SuiteCRM Demo login page at {string}")
    public void i_open_the_suiteCRM_demo_login_page_at(String url) {
        BaseClass.driver.get(url);
    }

    @And("I enter demo username {string} and password {string}")
    public void i_enter_demo_username_and_password(String username, String password) {
        BaseClass.builder.pause(Duration.ofSeconds(5)).build().perform();

        WebElement usernameField = BaseClass.driver.findElement(By.xpath("//input[@name='user_name']"));
        WebElement passwordField = BaseClass.driver.findElement(By.xpath("//input[@name='username_password']"));

        Action loginAction = BaseClass.builder
                .click(usernameField).sendKeys(username)
                .pause(Duration.ofSeconds(1))
                .click(passwordField).sendKeys(password)
                .pause(Duration.ofSeconds(1))
                .build();
        loginAction.perform();
    }

    @And("I click the demo login button")
    public void i_click_the_demo_login_button() {
        WebElement loginButton = BaseClass.driver.findElement(By.xpath("//input[@id='bigbutton']"));
        loginButton.click();
    }

    @And("I wait for the demo dashboard to load")
    public void i_wait_for_the_demo_dashboard_to_load() {
        BaseClass.builder.pause(Duration.ofSeconds(5)).build().perform();
        BaseClass.wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("nav")));
    }
}
