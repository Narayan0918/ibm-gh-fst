package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import io.cucumber.java.en.Then;

/**
 * Unique step definitions for navbar_colour.feature.
 * Accesses driver via BaseClass static fields — no inheritance needed.
 */
public class NavbarColourSteps {

    @Then("the navbar CSS colour should be {string}")
    public void the_navbar_css_colour_should_be(String expectedColour) {
        WebElement navbar = BaseClass.driver.findElement(
                By.xpath("//div[@class='top-panel fixed-top ng-tns-c2316037842-2 ng-star-inserted']"));
        Assert.assertEquals(navbar.getCssValue("color"), expectedColour);
        System.out.println("Navbar Colour => " + navbar.getCssValue("color"));
    }
}
