package stepDefinitions;

/**
 * No unique steps for login_page.feature — all steps are in CommonSteps.
 * This class exists only so the glue package includes the feature's tag.
 */
public class LoginPageSteps {
}
