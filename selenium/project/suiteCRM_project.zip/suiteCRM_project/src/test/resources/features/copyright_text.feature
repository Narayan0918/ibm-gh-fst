@CopyrightText
Feature: Copyright Text Verification
  As a QA engineer
  I want to verify the copyright footer text on the SuiteCRM login page
  So that I can confirm the correct legal attribution is displayed

  Scenario: Verify login page title on copyright page
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    Then the browser title should be "SuiteCRM"

  Scenario: Verify copyright footer text
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    And I wait for the page to fully render
    Then the copyright footer text should be "© Supercharged by SuiteCRM © Powered By SugarCRM"
