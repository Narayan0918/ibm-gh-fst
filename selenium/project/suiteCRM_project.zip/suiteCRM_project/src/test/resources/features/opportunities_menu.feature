@OpportunitiesMenu
Feature: Opportunities Menu Verification
  As a QA engineer
  I want to verify that the Opportunities button is visible in the navigation bar after login
  So that I can confirm the navigation menu renders the correct items

  Scenario: Verify login page title on opportunities page
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    Then the browser title should be "SuiteCRM"

  Scenario: Verify Opportunities menu item is present after login
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    And I enter username "admin" and password "5Nx#I6BK%r3$8vz0ch"
    And I click the login button
    And I wait for the dashboard to load
    Then the Opportunities navigation button should be visible
    And the Opportunities button text should be "Opportunities"
