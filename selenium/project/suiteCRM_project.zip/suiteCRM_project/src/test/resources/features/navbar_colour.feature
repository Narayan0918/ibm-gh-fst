@NavbarColour
Feature: Navbar Colour Verification
  As a QA engineer
  I want to verify that the top navigation bar has the correct CSS colour after login
  So that I can confirm the UI theme is applied correctly

  Scenario: Verify login page title on navbar colour page
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    Then the browser title should be "SuiteCRM"

  Scenario: Verify navbar colour after successful login
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    And I enter username "admin" and password "5Nx#I6BK%r3$8vz0ch"
    And I click the login button
    And I wait for the dashboard to load
    Then the navbar CSS colour should be "rgb(33, 37, 41)"
