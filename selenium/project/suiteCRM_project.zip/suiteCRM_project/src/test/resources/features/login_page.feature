@LoginPage
Feature: Login Page Functionality
  As a QA engineer
  I want to verify the SuiteCRM login page title and that an admin user can log in successfully
  So that I can confirm authentication works as expected

  Scenario: Verify login page title
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    Then the browser title should be "SuiteCRM"

  Scenario: Admin user logs in successfully
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    And I enter username "admin" and password "5Nx#I6BK%r3$8vz0ch"
    And I click the login button
    Then the browser title should be "SuiteCRM"
