@HeaderUrl
Feature: Header Logo URL Verification
  As a QA engineer
  I want to verify that the SuiteCRM header contains a company logo image with a valid URL
  So that I can confirm the branding assets are loaded correctly

  Scenario: Verify login page title on header URL page
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    Then the browser title should be "SuiteCRM"

  Scenario: Retrieve the company logo image URL from the header
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    And I wait for the page to fully render
    Then the header company logo image source URL should be printed
