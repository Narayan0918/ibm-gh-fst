@UsernameFullname
Feature: Username and Full Name Verification in Leads
  As a QA engineer
  I want to verify that the Leads table in SuiteCRM Demo contains 20 rows
  and that full names and usernames are displayed correctly
  So that I can confirm lead data integrity

  Scenario: Verify login page title on SuiteCRM Demo
    Given I open the SuiteCRM Demo login page at "https://demo.suiteondemand.com/index.php?action=Login&module=Users"
    When the page finishes loading
    Then the browser title should be "SuiteCRM Demo"

  Scenario: Verify Leads table contains 20 rows and display fullname to username mapping
    Given I open the SuiteCRM Demo login page at "https://demo.suiteondemand.com/index.php?action=Login&module=Users"
    When the page finishes loading
    And I enter demo username "will" and password "will"
    And I click the demo login button
    And I wait for the demo dashboard to load
    And I hover over the Sales menu and click on Leads
    And I wait for the leads list table to load
    Then the leads table should contain 20 rows
    And the first 10 lead fullname and username pairs should be printed
