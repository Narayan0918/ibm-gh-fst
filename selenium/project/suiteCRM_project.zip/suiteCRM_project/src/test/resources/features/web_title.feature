@WebTitle
Feature: Web Title Verification
  As a QA engineer
  I want to verify that the SuiteCRM login page loads with the correct browser title
  So that I can confirm the application is reachable and correctly identified

  Scenario: Verify SuiteCRM login page title
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    Then the browser title should be "SuiteCRM"
