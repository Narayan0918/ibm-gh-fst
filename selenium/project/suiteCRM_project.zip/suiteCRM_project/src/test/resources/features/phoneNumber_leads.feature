@PhoneNumberLeads
Feature: Phone Number Verification in Leads
  As a QA engineer
  I want to verify that a lead's phone number is correctly displayed on the lead detail page
  So that I can confirm contact data is stored and shown accurately

  Scenario: Verify login page title on phone number page
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    Then the browser title should be "SuiteCRM"

  Scenario: Verify phone number of the first lead in the Leads module
    Given I open the SuiteCRM login page at "https://crm.alchemy.hguy.co"
    When the page finishes loading
    And I enter username "admin" and password "5Nx#I6BK%r3$8vz0ch"
    And I click the login button
    And I wait for the dashboard to load
    And I navigate to the Leads menu
    And I wait for the leads table to load
    And I click on the first lead in the table
    And I wait for the lead detail page to load
    Then the lead phone number should be "9828723342"
