@TableData
Feature: Accounts Table Data Verification
  As a QA engineer
  I want to verify that the Accounts table in SuiteCRM Demo contains the expected number of rows
  So that I can confirm data is loaded and paginated correctly

  Scenario: Verify login page title on SuiteCRM Demo
    Given I open the SuiteCRM Demo login page at "https://demo.suiteondemand.com/index.php?action=Login&module=Users"
    When the page finishes loading
    Then the browser title should be "SuiteCRM Demo"

  Scenario: Verify Accounts table contains 10 rows
    Given I open the SuiteCRM Demo login page at "https://demo.suiteondemand.com/index.php?action=Login&module=Users"
    When the page finishes loading
    And I enter demo username "will" and password "will"
    And I click the demo login button
    And I wait for the demo dashboard to load
    And I hover over the Sales menu and click on Accounts
    And I wait for the accounts table to load
    Then the accounts table should contain 10 rows
    And the first 5 account row texts should be printed
