package RestAssured;

import static org.hamcrest.CoreMatchers.equalTo;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

public class addPetPostMethodDemo {
	String ROOT_URI = "https://petstore.swagger.io/v2/pet";
	 
	@Test
	public void AddNewPet() {
	    // Write the request body
	    String reqBody = "{\"id\": 78232,\"name\": \"Naman\", \"status\": \"alive\"}";
	 
	    Response response = 
	        given().contentType(ContentType.JSON) // Set headers
	        .body(reqBody).when().post(ROOT_URI); // Send POST request
	 
	    // Print response of POST request
	    String body = response.getBody().asPrettyString();
	    System.out.println(body);
	    
	    response.then().statusCode(200);
	    response.then().body("status", equalTo("alive"));
	}
}
