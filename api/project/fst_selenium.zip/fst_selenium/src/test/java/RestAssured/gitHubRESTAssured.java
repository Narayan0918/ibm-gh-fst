package RestAssured;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class gitHubRESTAssured {

	
	String sshKey = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHr52dSFQzR9ivjte8qrNl+pe3ZB1/OTkEAXy8/loYgL azuread/narayanrajdubey@IBM-1Q4SR24";
	int sshKeyID;
	RequestSpecification requestSpec;
	
	@BeforeClass
	public void setUp() {
		
		String accessToken = "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";
		
		 requestSpec = new RequestSpecBuilder()
				// Set content type
				.setContentType(ContentType.JSON)
				// Set base URL
				.setBaseUri("https://api.github.com")
				.addHeader("Authorization", "Bearer " + accessToken)
				.addHeader("Accept", "application/vnd.github+json")
//				// Add query parameters
//				.addQueryParam("paramName","paramValue")
//				// Add path parameters
//				.addPathParam("paramName","paramValue")
//				// Build request specification
				.build();
	}
	
	
	@Test(priority = 1)
	public void postToGithub() {
		String reqBody = "{\"title\": \"TestAPIKey\",\"key\": \""+sshKey+"\"}";
		
		Response response = given().spec(requestSpec)
                        .contentType(ContentType.JSON)
                        .body(reqBody).when()
                        .post("/user/keys");
		
		Reporter.log(response.getBody().prettyPrint());

        response.then().statusCode(201);

        sshKeyID = response.jsonPath().getInt("id");

        System.out.println("POST: Created sshKeyID : " + sshKeyID);
        System.out.println("--------------------------------------------");

	}
	
	
	@Test(dependsOnMethods = "postToGithub" , priority = 2)
	public void getFromGithub() {
		Response response = given().spec(requestSpec)
                        .contentType(ContentType.JSON)
                        .pathParam("id", sshKeyID).when()
                        .get("/user/keys/{id}");

//        response.prettyPrint();
		Reporter.log(response.getBody().prettyPrint());

        response.then()
                .statusCode(200)
                .body("id", equalTo((int) sshKeyID));

        System.out.println("GET: SSH Key successfully created and fetched.");
        System.out.println("--------------------------------------------");

	}
	
	
	@Test(dependsOnMethods = "postToGithub",priority = 3)
	public void deleteFromGithub() {
		Response response = given().spec(requestSpec)
                        .contentType(ContentType.JSON)
                        .pathParam("id", sshKeyID).when()
                        .delete("/user/keys/{id}");

//        response.prettyPrint();
		Reporter.log(response.getBody().prettyPrint());

        response.then()
                .statusCode(204);

        System.out.println("DELETE: SSH Key successfully Deleted \n");
        System.out.println("--------------------------------------------");
	}
	
	

	
}
