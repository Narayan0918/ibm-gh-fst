package RestAssured;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

public class queryParamDemo {
	
final static String ROOT_URI = "http://ip-api.com/json/{ipAddress}";
 
@Test
public void getIPInformation() {
    Response response = 
        given().contentType(ContentType.JSON) // Set headers
        // Add query parameter
        .when().queryParam("fields", "query,country,city,timezone")
        .pathParam("ipAddress", "125.219.5.94")
        .get(ROOT_URI); // Send GET request
    
    // Print response
    System.out.println(response.getBody().asPrettyString());
}
}
