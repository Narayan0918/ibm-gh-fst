package RestAssured;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class petStoreHandler {

    private static final String ROOT_URI = "https://petstore.swagger.io/v2/pet";

    // Shared pet ID across all test methods
    private long petId;

    @Test(priority = 1)
    public void addNewPet() {

        String reqBody = "{\n" +
                "\"id\": 78232,\n" +
                "\"name\": \"Naman\",\n" +
                "\"status\": \"alive\"\n" +
                "}";

        Response response =
                given()
                        .contentType(ContentType.JSON)
                        .body(reqBody)
                .when()
                        .post(ROOT_URI);

        response.prettyPrint();

        response.then()
                .statusCode(200)
                .body("name", equalTo("Naman"))
                .body("status", equalTo("alive"));

        // Capture ID from response
        petId = response.jsonPath().getLong("id");

        System.out.println("Created Pet ID : " + petId);
    }

    @Test(priority = 2, dependsOnMethods = "addNewPet")
    public void getPetAndVerifyCreation() {

        Response response =
                given()
                        .contentType(ContentType.JSON)
                        .pathParam("id", petId)
                .when()
                        .get(ROOT_URI + "/{id}");

        response.prettyPrint();

        response.then()
                .statusCode(200)
                .body("id", equalTo((int) petId))
                .body("name", equalTo("Naman"))
                .body("status", equalTo("alive"));

        System.out.println("Pet successfully created and fetched.");
    }

    @Test(priority = 3, dependsOnMethods = "getPetAndVerifyCreation")
    public void updatePet() {

        String updatedBody = "{\n" +
                "\"id\": " + petId + ",\n" +
                "\"name\": \"Sumit\",\n" +
                "\"status\": \"alive\"\n" +
                "}";

        Response response =
                given()
                        .contentType(ContentType.JSON)
                        .body(updatedBody)
                .when()
                        .put(ROOT_URI);

        response.prettyPrint();

        response.then()
                .statusCode(200)
                .body("id", equalTo((int) petId))
                .body("name", equalTo("Sumit"));

        System.out.println("Pet updated successfully.");
    }

    @Test(priority = 4, dependsOnMethods = "updatePet")
    public void verifyPetUpdated() {

        Response response =
                given()
                        .contentType(ContentType.JSON)
                        .pathParam("id", petId)
                .when()
                        .get(ROOT_URI + "/{id}");

        response.prettyPrint();

        response.then()
                .statusCode(200)
                .body("id", equalTo((int) petId))
                .body("name", equalTo("Sumit"))
                .body("status", equalTo("alive"));

        System.out.println("Update verified successfully.");
    }

    @Test(priority = 5, dependsOnMethods = "verifyPetUpdated")
    public void deletePet() {

        Response response =
                given()
                        .contentType(ContentType.JSON)
                        .pathParam("id", petId)
                .when()
                        .delete(ROOT_URI + "/{id}");

        response.prettyPrint();

        response.then()
                .statusCode(200);

        System.out.println("Pet deleted successfully.");
    }

    @Test(priority = 6, dependsOnMethods = "deletePet")
    public void verifyPetDeleted() {

        Response response =
                given()
                        .contentType(ContentType.JSON)
                        .pathParam("id", petId)
                .when()
                        .get(ROOT_URI + "/{id}");

        response.prettyPrint();

        response.then()
                .statusCode(404)
                .body("message", equalTo("Pet not found"));

        System.out.println("Deletion verified successfully.");
    }
}