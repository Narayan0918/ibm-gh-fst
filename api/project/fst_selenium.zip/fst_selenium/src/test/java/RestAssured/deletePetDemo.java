package RestAssured;

import static org.hamcrest.CoreMatchers.equalTo;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

public class deletePetDemo {
	String ROOT_URI = "https://petstore.swagger.io/v2/pet/{id}";
	 
	@Test
	public void AddNewPet() {
	    // Write the request body
	    String reqBody = "78232";
	 
	    Response response = 
	        given().contentType(ContentType.JSON) // Set headers
	        .pathParam("id",reqBody).when().delete(ROOT_URI); // Send DELETE request
	 
	    // Print response of POST request
	    String body = response.getBody().asPrettyString();
	    System.out.println(body);
	    
	    response.then().statusCode(200);
//	    response.then().body("name", equalTo("sumit"));
	}
}
